import spotipy
from spotipy.oauth2 import SpotifyOAuth
from optimization.threaded_processor import threaded_process
from utils.cache_u import load_from_cache, save_to_cache
from utils.helpers import chunker

# Spotify OAuth configuration
SPOTIFY_CLIENT_ID = "72474caf37cd4fd7b860f677916a9ca5"
SPOTIFY_CLIENT_SECRET = "0f6196902ccf47b5bc2a41c7fb56854e"
REDIRECT_URI = "http://127.0.0.1:8888/callback"
SCOPE = "playlist-modify-public playlist-modify-private"

# Initialize Spotify client with OAuth
sp = spotipy.Spotify(auth_manager=SpotifyOAuth(
    client_id=SPOTIFY_CLIENT_ID,
    client_secret=SPOTIFY_CLIENT_SECRET,
    redirect_uri=REDIRECT_URI,
    scope=SCOPE,
    cache_path=".cache"
))


def threaded_fetch_tracks(query: str, limit: int = 10, max_workers: int = 5):
    cache_key = f"{query.lower()}-{limit}"
    cached = load_from_cache(cache_key)
    if cached:
        print("⚡ Loaded from cache!")
        return cached

    def search_task(offset):
        results = sp.search(q=query, type='track', limit=1, offset=offset)
        items = results.get('tracks', {}).get('items', [])
        if items:
            item = items[0]
            return {
                'id': item['id'],
                'name': item['name'],
                'artist': item['artists'][0]['name']
            }
        return None

    offsets = list(range(limit * 2))  # Increase offset range to avoid duplicates from search API
    results = threaded_process(search_task, offsets, max_workers=max_workers)

    # Remove duplicates by track ID (most reliable)
    seen = set()  # Track unique IDs
    unique_tracks = []

    for track in results:
        if track:
            track_id = track['id']
            if track_id not in seen:  # Only add if the track ID is not seen before
                seen.add(track_id)
                unique_tracks.append(track)

    # Save to cache
    save_to_cache(cache_key, unique_tracks)
    return unique_tracks


def create_playlist_from_tracks(tracks: list, playlist_name: str = None, public: bool = False):
    """
    Create a Spotify playlist from a list of track dicts.
    Each track dict must contain 'id'.
    """
    user_id = sp.current_user()['id']
    if not playlist_name:
        playlist_name = "Generated Playlist"

    # Create playlist
    playlist = sp.user_playlist_create(user=user_id, name=playlist_name, public=public)
    track_uris = [f"spotify:track:{t['id']}" for t in tracks]

    # Add tracks in batches of 100 (Spotify limit)
    for i in range(0, len(track_uris), 100):
        sp.playlist_add_items(playlist_id=playlist['id'], items=track_uris[i:i+100])

    print(f"\n✅ Playlist '{playlist_name}' created with {len(track_uris)} tracks!")
    return playlist['id']
